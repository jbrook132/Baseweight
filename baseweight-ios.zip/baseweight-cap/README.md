# Baseweight — iOS App Build Guide

A LighterPack-style backpacking gear list tracker, built with React + Capacitor.

---

## What you need before starting

Install these on your Mac (one-time setup):

| Tool | Install |
|------|---------|
| **Xcode** | Mac App Store → search "Xcode" → Install (it's free, ~12GB) |
| **Node.js** | https://nodejs.org → download the LTS version |
| **CocoaPods** | Open Terminal → run: `sudo gem install cocoapods` |
| **Apple Developer account** | https://developer.apple.com → enrol ($99/year) |

---

## Step 1 — First-time setup (run once in Terminal)

Open Terminal, navigate to this folder, then run:

```bash
npm install
npx cap sync
cd ios/App
pod install
```

> `pod install` downloads the native iOS dependencies (~2 min on first run).

---

## Step 2 — Open in Xcode

From the `ios/App` folder:

```bash
open App.xcworkspace
```

> ⚠️ Always open `App.xcworkspace` (not `App.xcodeproj`). The workspace includes CocoaPods.

---

## Step 3 — Set your Bundle ID and signing

This is the step that connects the app to your Apple Developer account.

1. In Xcode's left sidebar, click **App** (the top-level blue icon)
2. Click the **App** target under "Targets"
3. Go to the **Signing & Capabilities** tab
4. Under **Team**, select your Apple Developer account
5. Change **Bundle Identifier** from `com.baseweight.app` to something unique:
   - Use your own domain reversed, e.g. `com.yourname.baseweight`
   - Or `io.github.yourusername.baseweight`
   - Must be unique across the entire App Store

Xcode will automatically handle provisioning profiles once your Team is set.

---

## Step 4 — Test on your iPhone

1. Plug in your iPhone via USB
2. In Xcode's toolbar, select your iPhone from the device dropdown
3. Press **▶ Run** (or Cmd+R)
4. The app will install and launch on your phone
5. Trust the developer certificate on your iPhone:
   - Settings → General → VPN & Device Management → your Apple ID → Trust

---

## Step 5 — Submit to the App Store

**Create your App Store listing first:**

1. Go to https://appstoreconnect.apple.com
2. Click **My Apps** → **+** → **New App**
3. Fill in:
   - Platform: iOS
   - Name: Baseweight
   - Bundle ID: (the one you set in Xcode)
   - SKU: `baseweight-1` (any unique string)
   - Language: English

**Take screenshots** (required before submission):

You need screenshots for at least 2 device sizes:
- 6.9" display (iPhone 16 Pro Max): 1320×2868px
- 6.5" display (iPhone 11 Pro Max): 1242×2688px

Easiest way: run the app in Xcode Simulator (select "iPhone 16 Pro Max" from device list), take screenshots with Cmd+S.

**Archive and upload:**

1. In Xcode: select **Any iOS Device** from the device dropdown (top toolbar)
2. Menu → **Product → Archive**
3. When the Organizer window opens, click **Distribute App**
4. Choose **App Store Connect** → **Upload**
5. Follow the prompts (defaults are fine)

**Submit for review:**

1. Back in App Store Connect, your build will appear under the version
2. Fill in the description, keywords, category (Health & Fitness or Utilities)
3. Add a **Privacy Policy URL** — required. Easiest: create a free page at https://www.privacypolicygenerator.info and paste the URL
4. Click **Submit for Review**
5. Apple reviews in 1–3 days

---

## Updating the app

When you want to change the gear list data or app features:

1. Edit `src/app.jsx`
2. Run `npm run build` (rebuilds `www/app.js`)
3. Run `npx cap sync` (copies updated web assets into the iOS project)
4. Open Xcode, bump the version number (e.g. 1.0.0 → 1.1.0)
5. Archive and upload again

---

## Changing the app name

- **Display name**: Xcode → App target → General → Display Name
- **App Store name**: App Store Connect (can differ from display name)

---

## File structure

```
baseweight-cap/
├── src/
│   └── app.jsx          ← All the app code lives here
├── www/
│   └── index.html       ← HTML shell (no need to touch this)
│   └── app.js           ← Built bundle (auto-generated, don't edit)
├── ios/
│   └── App/             ← Open App.xcworkspace from here
├── resources/
│   └── icon.png         ← Source icon (1024×1024)
└── capacitor.config.json
```

---

## Bundle ID quick note

The Bundle ID (`com.baseweight.app`) in this project is a placeholder. You **must** change it to your own before submitting. Once you submit with a Bundle ID, it's permanent — you can't change it later without creating a new App Store listing.
